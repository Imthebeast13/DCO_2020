package pt.tooyummytogo.facade.exception;

/**
 * @authors:
 * 
 * fc53512 Ana Albuquerque
 * fc44999 Andre Firmino
 * fc53683 Joao Godinho
 */
public class UtilizadorExistenteException extends Exception {
	//TODO 
}
