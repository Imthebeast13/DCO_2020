package pt.tooyummytogo.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestLogin {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
